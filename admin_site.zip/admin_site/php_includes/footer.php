<div class="footer">
  <p>Copyright @ 2018 | All rights reserved by <a href="#!"> www.example.com </a></p>
</div>
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: black;
   color: white;
   text-align: center;
   height: 50px;
   line-height: 50px;
   font-size: 16px;
}
</style>