<?php include("../php_stuffs/connection.php"); ?>
<?php
if(isset($_POST["action"]) && $_POST["action"] != "")
{
    $action = $_POST["action"];

    if($action == "all")
    {
        $product_get_query = mysqli_query($con, "SELECT * FROM `products` WHERE `product_removed`='0' ORDER BY `product_name` ASC");
        $product_num_query = mysqli_num_rows($product_get_query);
        if($product_num_query > 0)
        {
            while($product_fetch_query = mysqli_fetch_array($product_get_query))
            {
                $get_product_id = $product_fetch_query["product_id"];
                $get_product_name = $product_fetch_query["product_name"];
                $get_product_quantity = $product_fetch_query["product_quantity"];
                $get_product_sold = $product_fetch_query["product_sold"];
                $get_product_log = $product_fetch_query["product_logs"];
?>
                <tr id="del<?php echo $get_product_id; ?>">
                    <td><?php echo $get_product_name; ?></td>
                    <td><?php echo $get_product_quantity; ?></td>
                    <td><?php echo $get_product_sold; ?></td>
                    <td><?php echo $get_product_quantity-$get_product_sold; ?></td>
                </tr>
<?php
            }
        }
    
    }
}
?>